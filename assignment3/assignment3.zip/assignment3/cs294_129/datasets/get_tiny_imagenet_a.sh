wget http://cs231n.stanford.edu/tiny-imagenet-100-A.zip
unzip tiny-imagenet-100-A.zip
rm tiny-imagenet-100-A.zip
